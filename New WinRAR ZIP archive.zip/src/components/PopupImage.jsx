import { useEffect, useState } from "react";

export default function PopupImage() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // timer automat după 30 de secunde
    const timer = setTimeout(() => setShow(true), 30000);

    // expunem funcțiile globale în fereastra browserului
    window.showPopup = () => setShow(true);
    window.hidePopup = () => setShow(false);

    // debug: vezi în consolă că efectul s-a rulat
    console.log("PopupImage mounted -> ai acum window.showPopup()");

    return () => {
      clearTimeout(timer);
      // curățăm când componenta se demontează
      delete window.showPopup;
      delete window.hidePopup;
    };
  }, []);

  if (!show) return null;

  return (
    <div className="popup-container">
      <div className="popup">
        <img src="/promo.png" alt="Promo" />
        <button className="close-btn" onClick={() => setShow(false)}>×</button>
      </div>
    </div>
  );
}
